plumed --no-mpi driver --plumed plumed.dat --noatoms > plumed.out
